"""
Take in the encoding dictionary as well as an encoded TCRs object (npy file).
Use the dictionary to remove from the object all columns that:
    * represent beta chains, or
    * represent CDR1, CDR2 from alpha or beta chains
    
python _1b_remove_chains.py asdf C:/Users/Jeffrey/Documents/Programming/NIH_2021/antigen_recognition/data/GIL/small_encoded.npy C:/Users/Jeffrey/Documents/Programming/NIH_2021/antigen_recognition/comparison
    
"""
import pickle, numpy as np, pandas as pd
import argparse, os

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("encoding_dict", help="The pickle file associating each kmer type with an index.")
    parser.add_argument("encoded_obj", help="The encoded TCRs file. This should be a npy file.")
    parser.add_argument("output_dir", help="Where to save the new encoded objects.")
    args = parser.parse_args()

    with open(args.encoding_dict, "rb") as f:
        encoding_dict=pickle.load(f)
    
    tcrs_obj = np.load(args.encoded_obj)

    # the names of new types of dicts, and which types of kmers to remove.
    bad_feats={"only_beta":["alpha"],
    "only_cd3r":["cdr1","cdr2"]}
    
    for trim_type in bad_feats.keys():
        new_kmer_num=0
        bad_strings=bad_feats[trim_type]
        cols_to_keep = []
        new_dict={}
        for kmer_name in encoding_dict.keys():
            keep_string=True
            for bad_string in bad_strings:
                if bad_string in kmer_name:
                    keep_string=False
            if keep_string:
                cols_to_keep.append(encoding_dict[kmer_name])
                new_dict[kmer_name]=new_kmer_num
                new_kmer_num+=1

        print("For feature",trim_type,"keeping {} features out of {}!".format(len(cols_to_keep), len(encoding_dict)))
        new_obj=tcrs_obj[:,cols_to_keep] # keep all rows, remove some columns            
        
        np.save(os.path.join(args.output_dir, trim_type + "_obj"), new_obj)
        
        with open(os.path.join(args.output_dir, trim_type + "_new_dict.p"), "wb") as f:
            pickle.dump(new_dict, f)
        
        