"""
Use a random forest algorithm to train antigen binding predictions

"""
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import roc_auc_score
from sklearn.metrics import roc_curve
import matplotlib.pyplot as plt
import numpy as np, argparse
import pickle, os, time, logging

def get_imbalance_split(b, n, split_num, random_state_object):
	""""""
	nonbinding_larger = False
	if b.shape[0] < n.shape[0]:
		smaller_set, larger_set = b, n
		nonbinding_larger = True
	else:
		smaller_set, larger_set = n, b
		nonbinding_larger = False

	imbalance_ratio = larger_set.shape[0] / smaller_set.shape[0]
	logging.info("Imbalance splitting; maximum small sets of {}.".format(int(imbalance_ratio)))

	random_idx = random_state_object.choice(range(len(larger_set)), replace=False, size=len(larger_set))
	if split_num < int(imbalance_ratio): 
		r_n = random_idx[split_num*smaller_set.shape[0]:(split_num+1)*smaller_set.shape[0]]
	else:
		r_n = random_idx[smaller_set.shape[0]*(int(imbalance_ratio)-1):]

	new_larger_set = larger_set[r_n]

	if nonbinding_larger:
		return b, new_larger_set
	else:
		return new_larger_set, n

if __name__ == "__main__":
	parser = argparse.ArgumentParser()
	parser.add_argument("input_m1_matrix")
	parser.add_argument("input_non_m1_matrix")
	parser.add_argument("--n_estimators", required=False, nargs="+", default=100, type=int)
	parser.add_argument("--runs", required=False, default=5, type=int)
	parser.add_argument("--save_model", action="store_true")
	parser.add_argument("--model_name", required=False, default="./RF_model.p")
	parser.add_argument("--max_features", required=False, default=["auto"], nargs="+", help="Fraction of random variables to try when selecting best features.")
	parser.add_argument("--min_samples_leaf", required=False, default=1, type=int, help="The number of samples to be considered before reaching a leaf node.")
	parser.add_argument("--do_imbalance_match", action="store_true", help="Whether to positive and negative sets into approximately equal sizes.")
	parser.add_argument("--split_num", type=int, default=0, required=False, help="Which of the smaller split sets to use.")
	parser.add_argument("--minority_weight", type=int, default=1, help="What weight to assign to the minority set.")
	args = parser.parse_args()

	r = np.random.RandomState(100)
	logging.basicConfig(level=logging.INFO)

	m1 = np.load(args.input_m1_matrix)
	non_m1 = np.load(args.input_non_m1_matrix)

	if args.do_imbalance_match:

		m1, non_m1 = get_imbalance_split(m1, non_m1, args.split_num, r)

	m1_len, non_m1_shape = m1.shape[0], non_m1.shape[0]
	all_x = np.vstack((m1, non_m1))
	del non_m1
	all_y = np.concatenate((np.ones(m1_len), np.zeros(non_m1_shape)))

	if args.minority_weight != 1:
		weights = { 0:1, 1:args.minority_weight}
	else:
		weights="balanced"

	logging.info("""Training on {} positive, {} negative samples.
Using {} variables.
Variable values:
n_estimators: {}
max_features: {}
min_samples_leaf: {}
minority_weight: {}
""".format(m1_len, non_m1_shape, m1.shape[1], args.n_estimators, args.max_features, args.min_samples_leaf, args.minority_weight))

	### fit the Random Forest
	for trees in args.n_estimators:
		if len(args.n_estimators) > 1:
			logging.info("Using trees={}".format(trees))
		for mtry in args.max_features:
			if mtry not in  ("auto", "sqrt", "log2"):
				mtry = int(mtry)

			if len(args.max_features) > 1:
				logging.info("Using max_features={}".format(mtry))

			for i in range(args.runs):
				start = time.time()
				RF = RandomForestClassifier(class_weight = weights, n_estimators=trees, random_state=i, oob_score=True,
					max_features=mtry, min_samples_leaf=args.min_samples_leaf)
				RF.fit(all_x, all_y)
				fitting_time = time.time() - start
				logging.info("Fit took {0:.2f} seconds, with oob_score_: {1:.4f}".format(fitting_time, RF.oob_score_))

	if args.save_model:
		with open(args.model_name, "wb") as f:
			pickle.dump(RF, f)

