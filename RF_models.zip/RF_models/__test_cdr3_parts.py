"""


"""
import matplotlib.pyplot as plt, numpy as np 
import pandas as pd

def return_colored_array(Le, Ls, C, Rs, Re, tot_len=25):
	colored = np.array([color_key["none"] for i in range(tot_len)])
	colored[0:Le] = color_key["end"]
	colored[Le:Le+Ls] = color_key["side"]
	colored[Le+Ls:Le+Ls+C] = color_key["center"]
	colored[Le+Ls+C:Le+Ls+C+Rs] = color_key["side"]
	colored[Le+Ls+C+Rs:Le+Ls+C+Rs+Re] = color_key["end"]

	colored = colored.reshape((1, len(colored)))
	return colored

def cdr3_splitting(l):
	"""Return regions sizes based on CDR3 len"""
	color_line = np.array([0, 0, 0, 0, 0])

	to_add = l
	if l < 9:
		return 0, 0, l, 0, 0

	if l < 15:
		to_add = l%3
		color_line = np.array([int(l/3), 0, int(l/3), 0, int(l/3)])
	
	while to_add:
		
		if to_add == 1:
			color_line += np.array([0, 0, 1, 0, 0])
			break
		if to_add == 2:
			color_line += np.array([0, 0, 2, 0, 0])
			break

		# if (color_line[1] < 3) and (color_line[3] < 3) and to_add in (3,4):
		if to_add in (3,4):
			if to_add == 3:
				color_line += np.array([0, 1, 1, 1, 0])
			if to_add == 4:
				color_line += np.array([0, 1, 2, 1, 0])
			break
		else:
			if to_add <= 4:
				color_line += np.array([0, 0, to_add, 0, 0])
				break

		if to_add > 4:
			if (color_line[0] < 5) and (color_line[4] < 5):
				color_line += np.array([1, 1, 1, 1, 1])
			else:
				# if (color_line[1] < 3) and (color_line[3] < 3): # check if sides can be added to
				color_line += np.array([0, 1, 3, 1, 0])
				# else:
				# 	color_line += np.array([0, 0, 5, 0, 0])

			to_add -= 5
		else:
			break

	le, ls, c, rs, re = color_line
	return le, ls, c, rs, re

def get_splitting_tags(kmer_size=3):
	"""Return a dictionary with region for each idx in a CDR3 of the given length"""

	regions_dict = {}

	region_name = {"0":"-End-L",
					"1":"-Side-L",
					"2":"-Center",
					"3":"-Side-R",
					"4":"-End-R"}
	weng_spec_split={
		5:np.array([0,1,1,1,0]), 6:np.array([0,1,2,1,0]), 7:np.array([0,1,3,1,0]), 8:np.array([1,1,3,1,0]), 9:np.array([1,1,3,1,1]),
		10:np.array([1,1,4,1,1]), 11:np.array([1,2,4,1,1]), 12:np.array([1,2,4,2,1]), 13:np.array([2,2,4,2,1]), 14:np.array([2,2,4,2,2]),
		15:np.array([2,2,5,2,2]), 16:np.array([2,3,5,2,2]), 17:np.array([2,3,5,3,2]), 18:np.array([3,3,5,3,2]), 19:np.array([3,3,5,3,3]),
		20:np.array([3,3,6,3,3]), 21:np.array([3,3,7,3,3]), 22:np.array([3,4,7,3,3]), 23:np.array([3,4,7,4,3]), 24:np.array([3,4,8,4,3]),
		25:np.array([4,4,8,4,3]), 26:np.array([4,4,8,4,4]), 27:np.array([4,4,9,4,4]), 28:np.array([4,4,10,4,4]), 29:np.array([4,4,11,4,4]),
		30:np.array([4,4,12,4,4])
	}

	for l in range(5, 31):
		# le, ls, c, rs, re = cdr3_splitting(l)
		le, ls, c, rs, re = weng_spec_split[l]
		splitting = [le, ls, c, rs, re]
		splitting_starts = [ sum(splitting[:i]) for i in range(len(splitting)) ]
		splitting_starts.append(sum(splitting))
		len_dict = {}
		for idx in range(l):
			# region_occupied = None
			# highest_passed = [ i for i in range(len(splitting_starts)) if (idx >= splitting_starts[i]) ]
			# lowest_unpassed = [ i for i in range(len(splitting_starts)) if (idx+kmer_size)<=splitting_starts[i] ]

			# if (len(highest_passed)==0) | (len(lowest_unpassed)==0):
			# 	len_dict[idx] = region_occupied
			# 	continue

			# highest_passed = max(highest_passed)	
			# lowest_unpassed = min(lowest_unpassed)
			# if (highest_passed+1) == lowest_unpassed:
			# 	region_occupied = region_name[str(highest_passed)]
			# len_dict[idx] = region_occupied
			highest_region_passed = [ i for i in range(len(splitting_starts)) if (idx >= splitting_starts[i]) ]
			highest_region_passed = max(highest_region_passed)
			region_occupied = region_name.get(str(highest_region_passed), None)
			len_dict[idx] = region_occupied

		regions_dict[l] = len_dict

	return regions_dict

if __name__ == "__main__":
	color_key = {"end":0,
	"none":0.5,
	"side":1.00,
	"center":0.75}

	# all_sizes = range(5, 31)
	# max_len = max(all_sizes)
	# colored_chains = np.zeros((len(all_sizes), max_len)) + color_key["none"]

	# regions_dict = get_splitting_tags(30, 3)

	# for l in regions_dict.keys():
	# 	print(l)
	# 	print(regions_dict[l])

	# for idx, length in enumerate(all_sizes):
	# 	le, ls, c, rs, re = cdr3_splitting(length)
	# 	get_splitting_tags(length, 3)

	# 	new_colored = return_colored_array(le, ls, c, rs, re, max_len)
	# 	colored_chains[idx] = new_colored

	# plt.imshow(colored_chains, cmap="seismic", interpolation="nearest")
	# plt.xticks([i for i in range(max_len)], rotation="vertical")
	# plt.yticks([i for i in range(len(all_sizes))])
	# plt.savefig("CDR3_split_5end_noMaxSides.png")

	# df = pd.DataFrame(colored_chains)
	# df.to_csv("colored_cdr3_parts.csv", header=False, index=False)
