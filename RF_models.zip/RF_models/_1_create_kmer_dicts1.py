"""
Description:	Create kmer dictionary associating integers with each kmer seen in CDR1, CDR2, or CDR3 from either
	receptor chain. Encode the inputted receptors into vectors using this dictionary. Use DataFrame associating
	each v-gene with cdr regions to acquire kmers for these regions. 


Python Version:	Written and tested on 3.8.

Author: Jeffrey Cifello
"""
import pandas as pd 
import argparse, re, os
import numpy as np
import pickle, sys
from __test_cdr3_parts import get_splitting_tags

def get_v_seqs(v_genes, v_to_cdr_csv):
	cdr1, cdr2 = [], []

	not_found = set()
	trv_df = pd.read_csv(v_to_cdr_csv, index_col=0)
	counter = 0
	for i in v_genes:
		query = str(i)
		if ('DV' in query) and ('/DV' not in query) and ('_DV' not in query):
			query = query.replace('DV', '/DV') # any gene with DVX has a forward-slash in IMGT
		if ('_DV' in query) and ('/DV' not in query):
			query = query.replace('_DV', '/DV') # any gene with DVX has a forward-slash in IMGT

		if "-" in query:
			q_match = re.match("(TR[A|B]V[0-9]+\-[0-9]+)", query)
			if not q_match:
				counter += 1
				clean_match = re.match("(TR[A|B]V[0-9]+).*(\-[0-9]+)", query)
				if clean_match:
					query = clean_match.group(1)+clean_match.group(2)

				if query not in trv_df.index:
					query = query.split("-")[0]

		try:
			cdr1.append(trv_df.loc[query, 'cdr1'])
			cdr2.append(trv_df.loc[query, 'cdr2'])
		except KeyError:
			not_found.add(query)
			cdr1.append('')
			cdr2.append('')

	return cdr1, cdr2

def filter_csv(input_csv):
	"""Eliminate any rows containing empty slots."""
	filtered_df = pd.read_csv(input_csv)
	filtered_df = filtered_df.loc[(filtered_df['V-Gene Alpha'] != '') & 
								(filtered_df['CDR3 Alpha'] != '') &
								(filtered_df['J-Gene Alpha'] != '') &
								(filtered_df['V-Gene Beta'] != '') &
								(filtered_df['CDR3 Beta'] != '') &
								(filtered_df['J-Gene Beta'] != '') ]
	filtered_df = filtered_df.dropna(how='any')
	return filtered_df

def center_chain_pos_tag(idx_frac):
	"""With input float indicating fraction, return a tag"""
	if idx_frac < 0.3:
		return "-1st-third"
	if (idx_frac == 0.3) or (idx_frac < 0.70):
		# return "-2nd-third"
		return ""
	else:
		return "-3rd-third"

def create_kmer_dict(input_df, mode="generate", kmer_dict={}, kmer_size=3, cdr12_trimming=2, cdr3a_trimming=2, cdr3b_trimming=2, 
	cut_trim = False, combine=False, use_length=False, len_dep_cdr3t=False):
	"""Associate each kmer from each chain type with a number. This number will indicate
	which index of the 'one-hot' style encoding this kmer will indicate. Each chain will
	get a different kmer tag, e.g. SSG-cdr2a is distinct from SSG-cdr2b. 
	Kmer size: how many aa to put in each kmer
	trimming: how many aa to cut from each side of each chain
	"""
	if mode == "generate":
		try:
			kmer_num = max(kmer_dict.values())+1
		except ValueError:
			kmer_num = 0
	if mode == "encode":
		if use_length:
			encoded = np.zeros((len(input_df), len(kmer_dict.keys())+2))
		if not use_length:
			encoded = np.zeros((len(input_df), len(kmer_dict.keys())))
	if mode not in ("generate", "encode"):
		raise SystemError

	input_df.index = range(len(input_df))
	if combine: # if true, treat cdr1 and cdr2 as one big chain.
		input_df.loc[range(len(input_df)), "CDR1 Alpha"] = input_df["CDR1 Alpha"] + input_df["CDR2 Alpha"]
		input_df.loc[range(len(input_df)), "CDR1 Beta"] = input_df["CDR1 Beta"] + input_df["CDR2 Beta"]

		input_df.loc[range(len(input_df)), "CDR2 Alpha"] = [ '' for i in range(len(input_df)) ]
		input_df.loc[range(len(input_df)), "CDR2 Beta"] = [ '' for i in range(len(input_df)) ]

	chain_to_tag ={ i:i.lower().replace(' ', '-') for i in ("CDR1 Alpha", "CDR2 Alpha", "CDR3 Alpha", "CDR1 Beta", "CDR2 Beta", "CDR3 Beta") }
	chain_trimming = {"CDR1 Alpha":cdr12_trimming, "CDR2 Alpha":cdr12_trimming, "CDR3 Alpha":cdr3a_trimming,
					"CDR1 Beta":cdr12_trimming, "CDR2 Beta":cdr12_trimming, "CDR3 Beta":cdr3b_trimming }

	if len_dep_cdr3t:
		tag_dict = get_splitting_tags(kmer_size)

	for col in input_df.columns:
		chains = input_df[col].tolist()
		tag = chain_to_tag.get(col, None)
		trimming = chain_trimming.get(col, 0) # get trimming if applicable
		if ('V' not in col) and ('J' not in col):
			for idx, chain in enumerate(chains):
				#print(idx, chain)
				chain = str(chain)
				if "CDR3" in col:
					if mode=="encode" and use_length:
						if ("Alpha" in col): # include length in encoding if specified
							encoded[idx, -2] = len(chain)
						if ("Beta" in col):
							encoded[idx, -1] = len(chain)
				
				if len(chain) < kmer_size: # skip chain if no kmers can be pulled due to size
					continue
				
				for jdx in range(len(chain)-kmer_size+1):
					lower_trim, upper_trim = trimming, len(chain)-trimming-kmer_size

					trim_tag = ""
					
					if len_dep_cdr3t:
						try:
							if len_dep_cdr3t and ("CDR3" in col): # get tag for CDR3 kmer based on length and length-regions
								if (30 < len(chain)) or (5 > len(chain)): # or (not re.match("C(.*)F", chain)):
									continue
								trim_tag = tag_dict[len(chain)][jdx]
						except KeyError:
							print(input_df.loc[idx])
							print(len(chain))

						if trim_tag == None: # if kmer cannot be restricted to one region, do not consider
							continue
					else:
						if (jdx < lower_trim) or (upper_trim < jdx): # if kmer is outside of trimming areas
							if cut_trim:
								continue
							else:
								trim_tag = "-ON-EDGE"

					kmer = chain[jdx:jdx+kmer_size] + "-" + tag + trim_tag

					if mode == "generate":
						if kmer not in kmer_dict.keys():
							kmer_dict[kmer] = kmer_num
							kmer_num += 1
							# print(kmer, kmer_num)
					if mode == "encode":
						if kmer in kmer_dict.keys():
							kmer_idx = kmer_dict[kmer]
							encoded[idx, kmer_idx] = encoded[idx, kmer_idx]+1
		else:
			for idx, gene in enumerate(chains):
				if mode == "generate":
					if gene not in kmer_dict.keys():
						kmer_dict[gene] = kmer_num # just use kmer num for convenience
						kmer_num += 1
				if mode == "encode":
					if gene in kmer_dict.keys():
						kmer_idx = kmer_dict[gene]
						encoded[idx, kmer_idx] = encoded[idx, kmer_idx]+1

	if mode == "encode":
		return encoded
	if mode == "generate":
		return kmer_dict

if __name__ == '__main__':
	parser = argparse.ArgumentParser()
	parser.add_argument("run_mode", help="Whether to generate new dict or encode to existing", choices=["generate", "encode"]) # non-optional
	
	parser.add_argument("encoding_dict", help="encode: the dictionary used to encode the input. \
												generate: the new dictionary to be populated.") # non-optional
	parser.add_argument("--inputs", help="CSVs with paired v-cdr3-j sequences for receptors binding M1.", nargs='+', required=True) # required, but not positional
	parser.add_argument("--output_names", help="Where the binding and nonbinding tcrs should be saved after encoding.", nargs='+', required=True)
	parser.add_argument("--cdr12_trimming", help="How many aa to trim from each side of cdr1, cdr2.", default=0, type=int, required=False)
	parser.add_argument("--cdr3a_trimming", help="How many aa to trim from each side of cdr3-alpha.", default=0, type=int, required=False)
	parser.add_argument("--cdr3b_trimming", help="How many aa to trim from each side of cdr3-beta.", default=0, type=int, required=False)
	parser.add_argument("--cdr12_as_gene", help="Whether sto keep do fit on v, j gene.", choices=["True", "False"], default="False", required=False)
	parser.add_argument("--kmer_size", help="The number of amimo acids to use per kmer.", default=3, type=int, required=False)
	parser.add_argument("--combine_cdr1_cdr2", help="Whether to consider the cdr1 and cdr2 chains to only \
	 exist as one long chain. New combined chain will be considered cdr1. Cdr2 is essentially deleted.", choices=["True", "False"], default="False", required=False)
	parser.add_argument("--use_cdr3_length", help="Whether the cdr3 length is used as a variable in the RF.", choices=["True", "False"], default="False", required=False)
	parser.add_argument("--cut_trim", help="Whether trimmed portions are deleted or specially tagged.", choices=["True", "False"], default="False", required=False)
	parser.add_argument("--length_dependent_trimming", help="Whether to allow CDR3 length alone to determine trimming of CDR3s. Includes partitioning of center.", 
		choices=["True", "False"], default="False", required=False)
	args = parser.parse_args()

	bool_parse_d = { "True" : True, "False" : False }

	combine_cdr1_cdr2 = bool_parse_d[args.combine_cdr1_cdr2]
	cdr12_as_gene = bool_parse_d[args.cdr12_as_gene]
	use_cdr3_length = bool_parse_d[args.use_cdr3_length]
	cut_trim = bool_parse_d[args.cut_trim]
	len_dep_trim = bool_parse_d[args.length_dependent_trimming]

	if len(args.inputs) != len(args.output_names):
		print("Must have equivalent number of inputs and outputs.")
		sys.exit()

	if len_dep_trim and ((args.cdr3a_trimming != 0) or (args.cdr3b_trimming != 0)):
		print("Warning: CDR3 trim length specified as well as length_dependent_trimming. Length dependent trimming will override input trims.")

	inputs = args.inputs
	output_names = args.output_names

	### Get the CDR1 and CDR2 amino acid sequences associated with each v gene.
	selected_cols = ['cdr1_a', 'cdr2_a', 'CDR3 Alpha', 'cdr1_b', 'cdr2_b', 'CDR3 Beta']
	new_col_names = ["CDR1 Alpha", "CDR2 Alpha", "CDR3 Alpha", "CDR1 Beta", "CDR2 Beta", "CDR3 Beta"]
	formatted_dfs = {}

	trav_cdr_csv = "/data/TCR/antigen_recognition/data/random_forest/trav_cdr1_cdr2.csv"
	trbv_cdr_csv = "/data/TCR/antigen_recognition/data/random_forest/trbv_cdr1_cdr2.csv"

	for idx, inp in enumerate(inputs):
		# new_df = filter_csv(inp)
		new_df = pd.read_csv(inp)
		if not cdr12_as_gene:
			cdr1_a, cdr2_a = get_v_seqs(new_df['V-Gene Alpha'].tolist(), trav_cdr_csv)
			cdr1_b, cdr2_b = get_v_seqs(new_df['V-Gene Beta'].tolist(), trbv_cdr_csv)
			new_df['cdr1_a'] = cdr1_a
			new_df['cdr2_a'] = cdr2_a
			new_df['cdr1_b'] = cdr1_b
			new_df['cdr2_b'] = cdr2_b
			old_df = new_df # the TCR info before changing it
			new_df = new_df[selected_cols] # reorder then rename columns
			new_df.columns = new_col_names

		

		# old_df = old_df[["V-Gene Alpha", "CDR3 Alpha", "J-Gene Alpha", "V-Gene Beta", "CDR3 Beta", "J-Gene Beta"]]

		# new_df = new_df.loc[new_df.duplicated() == False]
		# old_df = old_df.loc[old_df.duplicated() == False]

		formatted_dfs[inp] = new_df

		## save filtered TCRs to the output data directory using the specified output name
		old_df.to_csv(os.path.join(os.path.split(args.output_names[idx])[0], os.path.split(args.output_names[idx])[1].split(".")[0]+"_trimmed_TCRs.csv"))

	if args.run_mode == "encode":
		with open(args.encoding_dict, 'rb') as f:
			kmer_dict = pickle.load(f)

	### Encode inputs via this dictionary
	if args.run_mode == "generate":
		kmer_dict = {}
		for inp in inputs:
			to_encode = formatted_dfs[inp]
			kmer_dict = create_kmer_dict(to_encode, mode="generate", kmer_dict=kmer_dict, kmer_size=args.kmer_size, cdr12_trimming=args.cdr12_trimming, cdr3a_trimming=args.cdr3a_trimming, 
				cdr3b_trimming=args.cdr3b_trimming, cut_trim=cut_trim, combine=combine_cdr1_cdr2, use_length=use_cdr3_length, len_dep_cdr3t=len_dep_trim)
	
	encoded_nps = {}
	for inp in inputs:
		new_encoded = create_kmer_dict(formatted_dfs[inp], mode="encode", kmer_dict=kmer_dict, kmer_size=args.kmer_size, cdr12_trimming=args.cdr12_trimming, cdr3a_trimming=args.cdr3a_trimming, 
			cdr3b_trimming=args.cdr3b_trimming, cut_trim=cut_trim, combine=combine_cdr1_cdr2, use_length=use_cdr3_length, len_dep_cdr3t=len_dep_trim)
		print(new_encoded.shape)
		encoded_nps[inp] = new_encoded

	### Save encoded binding and nonbinding tcrs, as well as dictionary used for encoding.
	for output_idx in range(len(output_names)):
		inp = inputs[output_idx]
		np.save(output_names[output_idx], encoded_nps[inp])

	for inp in formatted_dfs.keys():
		df = formatted_dfs[inp]
		df.to_csv(os.path.join(os.path.split(inp)[0], os.path.basename(inp).split(".")[0]+"_cdr_info.csv"), index=False)

	if args.run_mode == 'generate':
		with open(args.encoding_dict, 'wb') as f:
			print("Dictionary generated with {} keys.".format(len(kmer_dict.keys())))
			pickle.dump(kmer_dict, f)
