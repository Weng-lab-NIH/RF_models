"""
Info: Take in properly encoded test data and apply multiple random forest models. 
	Average the split models and write the results, in order or appearance of TCRs, to the 
	specified text output.
Python: 3.7+
"""


import os, glob, pickle
from sklearn.ensemble import RandomForestClassifier
import numpy as np
import re, argparse

if __name__ == "__main__":
	parser = argparse.ArgumentParser()
	parser.add_argument("model_dir", help="Where the trained random forest models are stored.")
	parser.add_argument("model_keyword", help="Text that leads the pickle files for the RF models.")
	parser.add_argument("test_encoded", help="Numpy object containing encoded TCRs to run through these RFs and average.")
	parser.add_argument("RF_out", help="Where to save the list of averaged RF predictions.")
	args = parser.parse_args()


	small_models = glob.glob(os.path.join(args.model_dir, "{}_*.p".format(args.model_keyword)))
	small_models.sort()
	print("Found {} models...".format(len(small_models)))

	print("Loading in encoded test set...")
	encoded = np.load(args.test_encoded)
	scores = np.zeros((len(small_models), encoded.shape[0]))

	for i in range(len(small_models)):
		if (i%10)==0:
			print("Loading RF {} of {}".format(i+1, len(small_models)))
		with open(small_models[i], "rb") as f:
			RF = pickle.load(f)

		preds = RF.predict_proba(encoded)[:, 1]
		scores[i] = preds

	avg_preds = np.mean(scores, axis=0)
	avg_preds = [ str(i) for i in avg_preds.flatten() ]
	f = open(args.RF_out, "w")
	f.write("\n".join(avg_preds))
	f.close()
